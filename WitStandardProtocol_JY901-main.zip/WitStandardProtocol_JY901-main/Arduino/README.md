# Instruction

The folder name is platform or language. Please find the corresponding folder according to your platform and programming language before using it

## Arduino_SDK Quick Start

https://support-73.gitbook.io/witmotion-sdk/wit-standard-protocol/sdk/arduino_sdk-quick-start

# 使用说明

文件夹名称为平台或者变成语言，使用前请按照您的所属平台和和所用编程语言来找对对应的文件夹

## 说明文档

https://wit-motion.yuque.com/wumwnr/ltst03/rqyk6g?singleDoc# 《Arduino_SDK快速上手》


